import controle.CtlAssinarPlano;
import fronteira.ViewAssinatura;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Ponto de entrada do sistema "Minha Refeicao".
 * Aqui so montamos os objetos (view e controller) e ligamos um ao outro.
 * Toda a logica do caso de uso "Assinar Plano de Refeicoes" fica no controller e nas entidades.
 */
public class Main {

    public static void main(String[] args) {
        // Scanner usado pela view para ler o que o assinante digita no terminal
        Scanner scanner = new Scanner(System.in);

        // Fronteira: a unica classe de interface com o assinante (terminal)
        ViewAssinatura view = new ViewAssinatura(scanner);

        // Controle: recebe a view e a pasta onde estao os arquivos CSV
        CtlAssinarPlano controller = new CtlAssinarPlano(view, localizarPastaDados());

        // A view precisa conhecer o controller para encaminhar as acoes do assinante
        view.setController(controller);

        try {
            view.executar(); // inicia o fluxo do caso de uso
        } catch (NoSuchElementException e) {
            // Acontece se a entrada de dados for encerrada (ex.: Ctrl+D)
            System.out.println();
            System.out.println("Entrada encerrada. Ate logo!");
        }
    }

    /**
     * Procura a pasta "dados" (com planos.csv e cardapio.csv):
     *  1) na pasta atual e subindo ate 3 niveis (ex.: executando de dentro de src);
     *  2) nas subpastas da pasta atual (ex.: o zip foi extraido dentro de outra pasta).
     * Se nao achar, encerra com uma mensagem clara.
     */
    private static Path localizarPastaDados() {
        Path inicio = Path.of("").toAbsolutePath();

        // 1) pasta atual e pastas acima
        Path atual = inicio;
        for (int nivel = 0; nivel < 4 && atual != null; nivel++) {
            if (temArquivosDeDados(atual.resolve("dados"))) {
                return confirmar(atual.resolve("dados"));
            }
            atual = atual.getParent();
        }

        // 2) subpastas diretas da pasta atual
        try (var subpastas = Files.list(inicio)) {
            for (Path sub : (Iterable<Path>) subpastas::iterator) {
                if (Files.isDirectory(sub) && temArquivosDeDados(sub.resolve("dados"))) {
                    return confirmar(sub.resolve("dados"));
                }
            }
        } catch (java.io.IOException e) {
            // ignora e segue para a mensagem de erro
        }

        System.out.println("ERRO: pasta 'dados' (com planos.csv e cardapio.csv) nao encontrada.");
        System.out.println("Pasta atual: " + inicio);
        System.out.println("Abra a pasta do projeto (que contem 'src' e 'dados') e execute novamente.");
        System.exit(1);
        return null; // nunca chega aqui
    }

    private static boolean temArquivosDeDados(Path pasta) {
        return Files.exists(pasta.resolve("planos.csv")) && Files.exists(pasta.resolve("cardapio.csv"));
    }

    private static Path confirmar(Path pasta) {
        System.out.println("Dados carregados de: " + pasta);
        return pasta;
    }
}
