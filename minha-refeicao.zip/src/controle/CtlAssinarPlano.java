package controle;

import entidade.Assinante;
import entidade.Assinatura;
import entidade.Cardapio;
import entidade.CartaoCredito;
import entidade.CodigoConfirmacao;
import entidade.ColecaoAssinaturas;
import entidade.ColecaoItensCardapio;
import entidade.ColecaoPlanos;
import entidade.ItemCardapio;
import entidade.OperadoraCartaoCredito;
import entidade.Pagamento;
import entidade.PlanoAssinatura;
import entidade.RespostaAutorizacao;
import fronteira.ViewAssinatura;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller do caso de uso "Assinar Plano de Refeicoes" (diagramas DS1 a DS5).
 *
 * Recebe as acoes do assinante vindas da view, coordena as entidades e pede a view
 * que exiba o resultado. Alguns metodos devolvem boolean/enum para a view saber
 * qual e o proximo passo (continuar, repetir uma pergunta, encerrar...).
 */
public class CtlAssinarPlano {

    /** Resultado da validacao do codigo SMS (fluxo principal ou fluxo alternativo FA1). */
    public enum ResultadoCodigo { VALIDO, INVALIDO, ESGOTADO }

    /** Resultado do cadastro do assinante (celular e e-mail nao podem ja existir). */
    public enum ResultadoCadastro { OK, CELULAR_JA_CADASTRADO, EMAIL_JA_CADASTRADO }

    // Colaboradores (recebidos no construtor)
    private final ViewAssinatura view;
    private final ColecaoPlanos colecaoPlanos;
    private final Cardapio cardapio;
    private final ColecaoAssinaturas colecaoAssinaturas;

    // Estado do caso de uso em andamento
    private Map<String, String> dadosCadastro; // nome, genero, email, celular
    private CodigoConfirmacao codigoConfirmacao;
    private Assinante assinante;
    private Assinatura assinatura;

    public CtlAssinarPlano(ViewAssinatura view, Path pastaDados) {
        this.view = view;
        // Planos e cardapio sao carregados dos arquivos CSV (pre-condicao do caso de uso)
        this.colecaoPlanos = new ColecaoPlanos(pastaDados.resolve("planos.csv"));
        this.cardapio = new Cardapio(new ColecaoItensCardapio(pastaDados.resolve("cardapio.csv")));
        this.colecaoAssinaturas = new ColecaoAssinaturas(pastaDados);
    }

    // ================================================================ DS1

    /**
     * Cadastro do assinante (nome, genero, e-mail e celular). O sistema RECUSA o cadastro se o celular
     * ou o e-mail ja pertencerem a um assinante. Se estiver tudo certo, envia o codigo por SMS.
     */
    public ResultadoCadastro informarCadastro(Map<String, String> dados) {
        if (colecaoAssinaturas.celularJaCadastrado(dados.get("celular"))) {
            view.exibirCadastroRecusado("Este numero de celular ja possui cadastro.");
            return ResultadoCadastro.CELULAR_JA_CADASTRADO;
        }
        if (colecaoAssinaturas.emailJaCadastrado(dados.get("email"))) {
            view.exibirCadastroRecusado("Este e-mail ja possui cadastro.");
            return ResultadoCadastro.EMAIL_JA_CADASTRADO;
        }
        this.dadosCadastro = dados;
        solicitarCodigo(dados.get("celular"));
        return ResultadoCadastro.OK;
    }

    /** DS1, mensagens 2 a 6: gera o codigo, envia por SMS e pede que o assinante o informe. */
    public void solicitarCodigo(String celular) {
        this.codigoConfirmacao = new CodigoConfirmacao(celular);
        codigoConfirmacao.gerar();
        codigoConfirmacao.enviarSMS(); // o codigo e enviado por SMS (simulado)
        view.exibirCampoCodigo();
    }

    /**
     * DS1, mensagens 8 a 16 (passos 4 e 5 do fluxo principal e FA1).
     * - codigo valido: cria o Assinante e exibe os planos;
     * - codigo invalido: avisa e permite nova tentativa;
     * - tres erros: encerra a validacao e pede um novo codigo.
     */
    public ResultadoCodigo validarCodigo(String codigo) {
        boolean valido = codigoConfirmacao.validar(codigo);
        if (valido) {
            this.assinante = new Assinante(dadosCadastro.get("nome"), dadosCadastro.get("genero"),
                    dadosCadastro.get("email"), codigoConfirmacao.getCelular());
            apresentarPlanos();
            return ResultadoCodigo.VALIDO;
        }
        // Codigo errado: FA1
        boolean esgotado = codigoConfirmacao.excedeuTentativas();
        if (!esgotado) {
            view.exibirCodigoInvalido();
            return ResultadoCodigo.INVALIDO;
        }
        view.solicitarNovoCodigo();
        return ResultadoCodigo.ESGOTADO;
    }

    /** DS1, mensagens 11 a 13: lista os planos disponiveis. */
    public void apresentarPlanos() {
        List<PlanoAssinatura> planos = colecaoPlanos.listar();
        // O controller le o resumo de cada plano; a view recebe so os textos (id -> resumo)
        Map<Integer, String> resumos = new LinkedHashMap<>();
        for (PlanoAssinatura plano : planos) {
            resumos.put(plano.getId(), plano.obterResumo());
        }
        view.exibirPlanos(resumos);
    }

    /**
     * O assinante NAO confirmou o resumo do pedido: descarta a assinatura e o pedido em elaboracao
     * e volta para a escolha do plano (o cadastro ja validado e mantido).
     */
    public void reiniciarSelecao() {
        this.assinatura = null;
        view.exibirPedidoNaoConfirmado();
        apresentarPlanos();
    }

    /** DS1, mensagens 18 a 22: cria a Assinatura (que cria o Pedido) e pede as preferencias. */
    public boolean selecionarPlano(int idPlano) {
        PlanoAssinatura plano = colecaoPlanos.buscar(idPlano);
        if (plano == null) {
            return false;
        }
        this.assinatura = new Assinatura(assinante, plano);
        view.exibirPreferenciasAlimentares();
        return true;
    }

    /** DS1, mensagens 24 a 26: guarda as preferencias alimentares no assinante. */
    public void registrarPreferencias(List<String> tipos) {
        assinante.registrarPreferencias(tipos);
    }

    // ================================================================ DS2

    /** DS2, mensagens 1 a 9: lista os itens da categoria que atendem as preferencias do assinante. */
    public void apresentarItens(String categoria) {
        int limite = assinatura.obterQuantidadeRefeicoes();
        List<ItemCardapio> itens = cardapio.listarItens(categoria, assinante.obterPreferencias());
        view.exibirItens(categoria, itens, limite);
    }

    /**
     * DS2, mensagens 11 a 20 (passos 12, 15 e 18 do fluxo principal e FA2).
     * Se a quantidade cabe no limite do plano, adiciona os itens ao pedido e devolve true.
     * Se passa do limite (FA2) ou, nos pratos principais, nao completa o plano, avisa e devolve
     * false para a view pedir uma nova selecao.
     *
     * @param selecoes mapa idItem -> quantidade escolhida
     */
    public boolean selecionarItens(String categoria, Map<Integer, Integer> selecoes) {
        int qtdSolicitada = selecoes.values().stream().mapToInt(Integer::intValue).sum();
        boolean valido = assinatura.validarQuantidade(categoria, qtdSolicitada);
        if (!valido) { // FA2: quantidade acima do plano
            view.exibirLimiteExcedido(assinatura.obterQuantidadeRefeicoes());
            return false;
        }
        // Regra complementar: os pratos principais precisam completar a quantidade do plano
        if (!assinatura.validarQuantidadeMinima(categoria, qtdSolicitada)) {
            view.exibirQuantidadeIncompleta(assinatura.obterQuantidadeRefeicoes(), qtdSolicitada);
            return false;
        }
        for (Map.Entry<Integer, Integer> selecao : selecoes.entrySet()) {
            ItemCardapio item = cardapio.buscarItem(selecao.getKey());
            assinatura.adicionarItem(item, selecao.getValue());
        }
        return true;
    }

    /** DS2, mensagens 21 a 24 (passo 19): mostra a composicao completa do pedido. */
    public void apresentarResumoPedido() {
        String resumo = assinatura.getPedido().obterResumo();
        view.exibirResumoPedido(resumo);
    }

    // ================================================================ DS3

    /** DS3, mensagens 1 e 2: pede o endereco de entrega. */
    public void solicitarEndereco() {
        view.exibirFormularioEndereco();
    }

    /**
     * DS3, mensagens 4 a 10 (passos 22 a 24): guarda o endereco, muda o status para
     * Aguardando Pagamento e mostra o valor total.
     */
    public void confirmarEndereco(Map<String, String> dadosEndereco) {
        assinatura.definirEndereco(dadosEndereco);
        assinatura.aguardarPagamento();
        BigDecimal valorTotal = assinatura.calcularValorTotal();
        view.exibirValorTotalEPagamento(valorTotal);
    }

    // ================================================================ DS4

    /**
     * DS4, mensagens 2 a 17 (passos 25 a 29 e FA3).
     * Cria cartao e pagamento, consulta a operadora e, se aprovado, ativa a assinatura.
     *
     * @return true se o pagamento foi aprovado; false se foi recusado
     */
    public boolean efetuarPagamento(Map<String, String> dadosCartao) {
        CartaoCredito cartao = assinante.cadastrarCartao(dadosCartao);
        Pagamento pagamento = assinatura.gerarPagamento(cartao);
        BigDecimal valor = pagamento.getValor();

        // Pede a autorizacao a operadora do cartao (simulada)
        OperadoraCartaoCredito operadora = new OperadoraCartaoCredito("Operadora " + cartao.getBandeira());
        RespostaAutorizacao resposta = operadora.solicitarAutorizacao(dadosCartao, valor);

        if (resposta.isAprovado()) {
            pagamento.registrarAutorizacao(operadora, resposta.getCodigoAutorizacao());
            assinatura.ativar(); // assinatura Ativa e pedido Aprovado
            return true;
        }
        // FA3: pagamento nao autorizado; a assinatura continua Aguardando Pagamento
        pagamento.registrarRecusa();
        view.exibirPagamentoNaoAprovado();
        return false;
    }

    /** DS4, mensagens 19 a 21 (FA3): o assinante desistiu; encerra sem ativar e grava o resultado. */
    public void encerrarProcesso() {
        assinatura.encerrarSemAtivacao();
        colecaoAssinaturas.salvar(assinatura);
        view.exibirProcessoEncerrado();
    }

    // ================================================================ DS5

    /** DS5, mensagens 1 a 9 (passos 30 e 31): gera o protocolo, grava nos CSV e exibe a confirmacao. */
    public void apresentarConfirmacao() {
        assinatura.gerarProtocolo();
        assinatura.calcularPrevisaoPrimeiraEntrega();
        String confirmacao = assinatura.obterDadosConfirmacao();
        colecaoAssinaturas.salvar(assinatura); // persistencia da assinatura ativa
        view.exibirConfirmacao(confirmacao);
    }
}
