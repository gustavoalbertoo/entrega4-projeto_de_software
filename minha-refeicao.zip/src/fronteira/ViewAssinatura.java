package fronteira;

import controle.CtlAssinarPlano;
import controle.CtlAssinarPlano.ResultadoCadastro;
import controle.CtlAssinarPlano.ResultadoCodigo;
import entidade.ItemCardapio;
import entidade.PreferenciaAlimentar;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

/**
 * Fronteira de interface (terminal) do caso de uso "Assinar Plano de Refeicoes".
 *
 * Esta classe tem tres grupos de metodos:
 *  1) executar(): conduz a sequencia dos passos do fluxo principal, lendo o que o assinante digita;
 *  2) informar*, selecionar*, cancelarAssinatura: acoes do assinante, encaminhadas ao controller;
 *  3) exibir* e solicitarNovoCodigo: chamados pelo controller para mostrar resultados na tela.
 */
public class ViewAssinatura {

    private static final Locale PT_BR = Locale.forLanguageTag("pt-BR");
    private static final String LINHA = "-".repeat(64);

    private final Scanner in;      // leitura do teclado
    private CtlAssinarPlano ctl;   // controller (definido por setController)

    // Listas guardadas na ultima exibicao, para validar o que o assinante digita
    private Map<Integer, String> planosExibidos = new LinkedHashMap<>(); // id -> resumo do plano
    private List<ItemCardapio> itensExibidos = new ArrayList<>();
    private int limiteExibido; // limite do plano na ultima listagem de itens

    public ViewAssinatura(Scanner in) {
        this.in = in;
    }

    public void setController(CtlAssinarPlano ctl) {
        this.ctl = ctl;
    }

    // =====================================================================
    // 1) Conducao do fluxo (passos do caso de uso)
    // =====================================================================

    public void executar() {
        System.out.println(LINHA);
        System.out.println("  MINHA REFEICAO - Assinatura de marmitas");
        System.out.println(LINHA);

        // ---- Cadastro e validacao do celular (passos 1 a 4, FA1 e cadastro duplicado)
        boolean validado = false;
        while (!validado) {
            // Cadastro: se o celular ou o e-mail ja existirem, o sistema recusa e pede os dados de novo
            Map<String, String> cadastro;
            do {
                cadastro = lerCadastro();
            } while (informarCadastro(cadastro) != ResultadoCadastro.OK); // OK = SMS enviado

            String celular = cadastro.get("celular");
            while (true) {
                ResultadoCodigo r = informarCodigo(lerLinha("Informe o codigo recebido por SMS: "));
                if (r == ResultadoCodigo.VALIDO) {
                    validado = true;
                    break;
                }
                if (r == ResultadoCodigo.ESGOTADO) {
                    // FA1: 3 erros. O assinante pede um novo codigo ou corrige o cadastro
                    String op = lerLinha("ENTER para reenviar o codigo ao mesmo celular ou N para corrigir o cadastro: ");
                    if (op.equalsIgnoreCase("N")) {
                        break; // volta ao cadastro
                    }
                    informarCelular(celular); // novo SMS; segue pedindo o codigo
                }
                // INVALIDO: pede o codigo de novo
            }
        }

        // ---- Montagem do pedido (passos 5 a 19). Se o assinante nao confirmar o resumo,
        //      o pedido e descartado e o processo volta para a escolha do plano.
        boolean pedidoConfirmado = false;
        while (!pedidoConfirmado) {
            // Escolha do plano (passos 5 e 6). Os planos ja foram exibidos pelo controller.
            Integer escolhido = null;
            while (escolhido == null) {
                int id = lerInteiro("Escolha o plano (informe o numero): ");
                if (!planosExibidos.containsKey(id)) {
                    System.out.println("  Plano inexistente. Tente novamente.");
                } else if (confirmar("Confirma o plano " + id + " (" + planosExibidos.get(id) + ")?")) {
                    escolhido = id;
                }
            }
            selecionarPlano(escolhido);

            // Preferencias alimentares (passos 7 a 9)
            informarPreferencias(lerPreferencias());

            // Pratos, acompanhamentos e sobremesas (passos 10 a 18 e FA2)
            for (String categoria : ItemCardapio.CATEGORIAS) {
                ctl.apresentarItens(categoria); // o controller manda exibir os itens da categoria
                if (itensExibidos.isEmpty()) {
                    continue; // nenhum item disponivel para as preferencias: pula a categoria
                }
                boolean ok = false;
                while (!ok) {
                    Map<Integer, Integer> selecoes = lerSelecoes(categoria);
                    ok = selecionarItens(categoria, selecoes); // false = FA2 / incompleto: pede de novo
                }
            }

            // Resumo do pedido (passo 19) e confirmacao pelo assinante
            ctl.apresentarResumoPedido();
            pedidoConfirmado = confirmar("Confirma o pedido?");
            if (!pedidoConfirmado) {
                ctl.reiniciarSelecao(); // descarta o pedido e mostra os planos novamente
            }
        }

        // ---- Endereco de entrega (passos 20 a 22)
        ctl.solicitarEndereco();
        Map<String, String> endereco = lerEndereco();
        informarEndereco(endereco);

        // ---- Pagamento (passos 25 a 29 e FA3)
        boolean pago = false;
        while (!pago) {
            pago = informarDadosCartao(lerDadosCartao());
            if (!pago && !confirmar("Deseja informar outro cartao?")) {
                cancelarAssinatura(); // FA3: o assinante desistiu
                return;
            }
        }

        // ---- Protocolo e mensagem de confirmacao (passos 30 a 32)
        ctl.apresentarConfirmacao();
    }

    // =====================================================================
    // 2) Acoes do assinante (apenas encaminham ao controller)
    // =====================================================================

    public ResultadoCadastro informarCadastro(Map<String, String> dadosCadastro) {
        return ctl.informarCadastro(dadosCadastro);
    }

    /** Reenvio do codigo SMS para o celular ja cadastrado. */
    public void informarCelular(String celular) {
        ctl.solicitarCodigo(celular);
    }

    public ResultadoCodigo informarCodigo(String codigo) {
        return ctl.validarCodigo(codigo);
    }

    public boolean selecionarPlano(int idPlano) {
        return ctl.selecionarPlano(idPlano);
    }

    public void informarPreferencias(List<String> tipos) {
        ctl.registrarPreferencias(tipos);
    }

    public boolean selecionarItens(String categoria, Map<Integer, Integer> selecoes) {
        return ctl.selecionarItens(categoria, selecoes);
    }

    public void informarEndereco(Map<String, String> dadosEndereco) {
        ctl.confirmarEndereco(dadosEndereco);
    }

    public boolean informarDadosCartao(Map<String, String> dadosCartao) {
        return ctl.efetuarPagamento(dadosCartao);
    }

    public void cancelarAssinatura() {
        ctl.encerrarProcesso();
    }

    // =====================================================================
    // 3) Exibicoes (chamadas pelo controller)
    // =====================================================================

    public void exibirCadastroRecusado(String motivo) {
        System.out.println("  CADASTRO RECUSADO: " + motivo + " Informe outros dados.");
    }

    public void exibirPedidoNaoConfirmado() {
        System.out.println();
        System.out.println("  Pedido nao confirmado e descartado. Vamos escolher o plano novamente.");
    }

    public void exibirCampoCodigo() {
        System.out.println("  Codigo enviado. Voce tem 3 tentativas para informa-lo.");
    }

    public void exibirCodigoInvalido() {
        System.out.println("  Codigo invalido. Tente novamente.");
    }

    public void solicitarNovoCodigo() {
        System.out.println("  Tres tentativas invalidas. A validacao foi encerrada; solicite um novo codigo.");
    }

    public void exibirPlanos(Map<Integer, String> resumosPorPlano) {
        this.planosExibidos = resumosPorPlano; // guarda para validar a escolha depois
        System.out.println();
        System.out.println("  Planos disponiveis:");
        System.out.println(LINHA);
        for (Map.Entry<Integer, String> plano : resumosPorPlano.entrySet()) {
            System.out.println("  [" + plano.getKey() + "] " + plano.getValue());
        }
        System.out.println(LINHA);
    }

    public void exibirPreferenciasAlimentares() {
        System.out.println();
        System.out.println("  Preferencias alimentares (pode escolher mais de uma, separadas por virgula):");
        System.out.println("  [1] " + PreferenciaAlimentar.TRADICIONAL);
        System.out.println("  [2] " + PreferenciaAlimentar.VEGETARIANA);
        System.out.println("  [3] " + PreferenciaAlimentar.SEM_LACTOSE);
    }

    public void exibirItens(String categoria, List<ItemCardapio> itens, int limite) {
        this.itensExibidos = itens; // guarda para validar os ids digitados
        this.limiteExibido = limite;
        System.out.println();
        System.out.println("  " + rotulo(categoria).toUpperCase() + " disponiveis (limite do plano: " + limite + ")");
        System.out.println(LINHA);
        if (itens.isEmpty()) {
            System.out.println("  Nenhum item disponivel para as suas preferencias.");
        }
        for (ItemCardapio i : itens) {
            System.out.printf("  [%d] %s - %s (%d kcal)%n", i.getId(), i.getNome(), i.getDescricao(), i.getCalorias());
        }
        System.out.println(LINHA);
    }

    public void exibirLimiteExcedido(int limite) {
        System.out.println("  Quantidade acima do permitido pelo plano (limite: " + limite
                + " por categoria). Ajuste a sua selecao.");
    }

    /** Pratos principais abaixo da quantidade do plano: o assinante precisa completar a selecao. */
    public void exibirQuantidadeIncompleta(int limite, int escolhida) {
        System.out.println("  Seu plano inclui " + limite + " refeicoes, mas voce escolheu " + escolhida
                + " prato(s) principal(is). Escolha exatamente " + limite + ".");
    }

    public void exibirResumoPedido(String resumo) {
        System.out.println();
        System.out.println("  RESUMO DO PEDIDO");
        System.out.println(LINHA);
        for (String linha : resumo.split("\n")) {
            System.out.println("  " + linha);
        }
        System.out.println(LINHA);
    }

    public void exibirFormularioEndereco() {
        System.out.println();
        System.out.println("  ENDERECO DE ENTREGA");
    }

    public void exibirValorTotalEPagamento(BigDecimal valorTotal) {
        System.out.println();
        System.out.println("  Status da assinatura: Aguardando Pagamento");
        System.out.println(String.format(PT_BR, "  VALOR TOTAL DA ASSINATURA: R$ %,.2f", valorTotal));
        System.out.println("  Informe os dados do cartao de credito.");
        System.out.println("  (Simulacao: final PAR = aprovado | final IMPAR = recusado)");
    }

    public void exibirPagamentoNaoAprovado() {
        System.out.println("  Pagamento NAO aprovado pela operadora. A assinatura segue Aguardando Pagamento.");
    }

    public void exibirProcessoEncerrado() {
        System.out.println();
        System.out.println("  Processo de assinatura encerrado sem ativacao do plano.");
    }

    public void exibirConfirmacao(String confirmacao) {
        System.out.println();
        System.out.println("  Pagamento aprovado! Assinatura ATIVA - Pedido APROVADO.");
        System.out.println(LINHA);
        System.out.println("  CONFIRMACAO DA ASSINATURA");
        System.out.println(LINHA);
        for (String linha : confirmacao.split("\n")) {
            System.out.println("  " + linha);
        }
        System.out.println(LINHA);
        System.out.println("  Obrigado por assinar a Minha Refeicao!");
    }

    // =====================================================================
    // Leitura e validacao do que o assinante digita
    // =====================================================================

    /** Le os dados cadastrais: nome, genero, e-mail e celular (com validacao de formato). */
    private Map<String, String> lerCadastro() {
        System.out.println();
        System.out.println("  CADASTRO DO ASSINANTE");
        Map<String, String> d = new LinkedHashMap<>();
        d.put("nome", lerObrigatorio("Nome completo: ", "[^;]{3,}"));
        String g = lerObrigatorio("Genero (1-Feminino, 2-Masculino, 3-Outro, 4-Prefiro nao informar): ", "[1-4]");
        d.put("genero", switch (g) {
            case "1" -> "Feminino";
            case "2" -> "Masculino";
            case "3" -> "Outro";
            default -> "Nao informado";
        });
        d.put("email", lerObrigatorio("E-mail: ", "[^@\\s;]+@[^@\\s;]+\\.[^@\\s;]+").toLowerCase());
        d.put("celular", lerCelular());
        return d;
    }

    /** Pede o celular ate o assinante digitar 10 ou 11 digitos. */
    private String lerCelular() {
        while (true) {
            String celular = normalizarCelular(lerLinha("Numero de celular (DDD + numero): "));
            if (celular != null) {
                return celular;
            }
            System.out.println("  Numero invalido. Use DDD + numero (10 ou 11 digitos).");
        }
    }

    /** Deixa so os digitos; devolve null se nao tiver 10 ou 11 digitos. */
    private String normalizarCelular(String texto) {
        String digitos = texto.replaceAll("\\D", "");
        return (digitos.length() == 10 || digitos.length() == 11) ? digitos : null;
    }

    /** Le as preferencias (ex.: "2,3") e converte os numeros nos tipos de preferencia. */
    private List<String> lerPreferencias() {
        while (true) {
            String entrada = lerLinha("Informe as preferencias (ex.: 2,3): ");
            List<String> tipos = new ArrayList<>();
            boolean erro = false;
            for (String parte : entrada.split("[,;\\s]+")) {
                String tipo = switch (parte) {
                    case "1" -> PreferenciaAlimentar.TRADICIONAL;
                    case "2" -> PreferenciaAlimentar.VEGETARIANA;
                    case "3" -> PreferenciaAlimentar.SEM_LACTOSE;
                    default -> null;
                };
                if (tipo == null) {
                    erro = true;
                    break;
                }
                if (!tipos.contains(tipo)) {
                    tipos.add(tipo); // evita repetir o mesmo tipo
                }
            }
            if (!erro && !tipos.isEmpty()) {
                return tipos;
            }
            System.out.println("  Opcao invalida. Informe numeros entre 1 e 3.");
        }
    }

    /**
     * Le a selecao de itens no formato "id:quantidade,id:quantidade" (ex.: 6:3,8:2).
     * Apenas "id" equivale a quantidade 1. Pratos principais sao obrigatorios e o total deve ser
     * igual a quantidade de refeicoes do plano; acompanhamentos e sobremesas podem ficar em branco.
     */
    private Map<Integer, Integer> lerSelecoes(String categoria) {
        boolean obrigatorio = categoria.equals(ItemCardapio.PRATO_PRINCIPAL);
        while (true) {
            String dica = obrigatorio ? "(total exato: " + limiteExibido + ")" : "(ENTER para nao escolher)";
            String entrada = lerLinha("Selecione " + rotulo(categoria).toLowerCase()
                    + " no formato id:qtd,id:qtd " + dica + ": ");
            Map<Integer, Integer> selecoes = new LinkedHashMap<>();
            if (entrada.isBlank() && !obrigatorio) {
                return selecoes; // nenhuma escolha nesta categoria
            }
            boolean erro = entrada.isBlank();
            for (String parte : entrada.split(",")) {
                if (erro) {
                    break;
                }
                String[] p = parte.trim().split(":");
                try {
                    int id = Integer.parseInt(p[0].trim());
                    int qtd = p.length > 1 ? Integer.parseInt(p[1].trim()) : 1;
                    // O id precisa ser de um item que foi mostrado na tela
                    boolean existe = false;
                    for (ItemCardapio i : itensExibidos) {
                        if (i.getId() == id) {
                            existe = true;
                        }
                    }
                    if (!existe || qtd <= 0 || p.length > 2) {
                        erro = true;
                    } else {
                        selecoes.merge(id, qtd, Integer::sum); // soma se o mesmo id for repetido
                    }
                } catch (NumberFormatException e) {
                    erro = true;
                }
            }
            if (!erro) {
                return selecoes;
            }
            System.out.println("  Selecao invalida. Use apenas os numeros listados acima (ex.: 1:2,3:1).");
        }
    }

    /** Le cada campo do endereco, mostra o resultado e pede confirmacao (passos 20 e 21). */
    private Map<String, String> lerEndereco() {
        while (true) {
            Map<String, String> d = new LinkedHashMap<>();
            d.put("cep", lerObrigatorio("CEP (8 digitos): ", "\\d{5}-?\\d{3}").replace("-", ""));
            d.put("logradouro", lerObrigatorio("Logradouro: ", ".+"));
            d.put("numero", lerObrigatorio("Numero: ", ".+"));
            d.put("complemento", lerLinha("Complemento (opcional): "));
            d.put("bairro", lerObrigatorio("Bairro: ", ".+"));
            d.put("cidade", lerObrigatorio("Cidade: ", ".+"));
            d.put("estado", lerObrigatorio("Estado (UF): ", "[A-Za-z]{2}").toUpperCase());
            System.out.println("  " + d.get("logradouro") + ", " + d.get("numero") + " - " + d.get("bairro")
                    + " - " + d.get("cidade") + "/" + d.get("estado") + " - CEP " + d.get("cep"));
            if (confirmar("Confirma o endereco de entrega?")) {
                return d;
            }
        }
    }

    /** Le os dados do cartao (numero, titular, validade e bandeira) com validacao basica de formato. */
    private Map<String, String> lerDadosCartao() {
        Map<String, String> d = new LinkedHashMap<>();
        d.put("numero", lerObrigatorio("Numero do cartao (13 a 19 digitos): ", "[\\d ]{13,23}").replace(" ", ""));
        d.put("nomeTitular", lerObrigatorio("Nome do titular: ", ".+"));
        while (true) {
            String validade = lerObrigatorio("Validade (MM/AA): ", "(0[1-9]|1[0-2])/\\d{2}");
            int mes = Integer.parseInt(validade.substring(0, 2));
            int ano = 2000 + Integer.parseInt(validade.substring(3));
            // Aceita o cartao se o mes/ano de validade nao for anterior ao mes atual
            if (!YearMonth.of(ano, mes).isBefore(YearMonth.from(LocalDate.now()))) {
                d.put("validade", validade);
                break;
            }
            System.out.println("  Cartao vencido. Informe outra validade.");
        }
        String bandeira = lerObrigatorio("Bandeira (1-Visa, 2-Mastercard, 3-Elo): ", "[1-3]");
        d.put("bandeira", switch (bandeira) {
            case "1" -> "Visa";
            case "2" -> "Mastercard";
            default -> "Elo";
        });
        return d;
    }

    /** Nome legivel de cada categoria para mostrar na tela. */
    private String rotulo(String categoria) {
        return switch (categoria) {
            case ItemCardapio.PRATO_PRINCIPAL -> "Pratos principais";
            case ItemCardapio.ACOMPANHAMENTO -> "Acompanhamentos";
            default -> "Sobremesas";
        };
    }

    // ---- Metodos auxiliares de leitura do teclado

    /** Mostra a pergunta e le uma linha digitada. */
    private String lerLinha(String prompt) {
        System.out.print("> " + prompt);
        return in.nextLine().trim();
    }

    /** Repete a pergunta ate a resposta combinar com a expressao regular informada. */
    private String lerObrigatorio(String prompt, String regex) {
        while (true) {
            String valor = lerLinha(prompt);
            if (valor.matches(regex)) {
                return valor;
            }
            System.out.println("  Valor invalido. Tente novamente.");
        }
    }

    /** Repete a pergunta ate o assinante digitar um numero inteiro. */
    private int lerInteiro(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(lerLinha(prompt));
            } catch (NumberFormatException e) {
                System.out.println("  Informe um numero valido.");
            }
        }
    }

    /** Pergunta S/N e devolve true para S. */
    private boolean confirmar(String pergunta) {
        while (true) {
            String r = lerLinha(pergunta + " (S/N): ").toUpperCase();
            if (r.equals("S")) {
                return true;
            }
            if (r.equals("N")) {
                return false;
            }
        }
    }
}
