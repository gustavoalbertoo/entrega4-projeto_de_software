package entidade;

import java.math.BigDecimal;
import java.util.Locale;

/**
 * Plano de assinatura oferecido pela plataforma: define a quantidade de refeicoes,
 * a periodicidade de entrega e o valor. Os planos sao carregados de dados/planos.csv.
 */
public class PlanoAssinatura {

    private final int id;
    private final String nome;
    private final int quantidadeRefeicoes;
    private final String periodicidade; // Semanal, Quinzenal ou Mensal
    private final BigDecimal valor;

    public PlanoAssinatura(int id, String nome, int quantidadeRefeicoes, String periodicidade, BigDecimal valor) {
        this.id = id;
        this.nome = nome;
        this.quantidadeRefeicoes = quantidadeRefeicoes;
        this.periodicidade = periodicidade;
        this.valor = valor;
    }

    /** Texto de uma linha com os dados do plano, mostrado ao assinante (DS1, mensagem 12). */
    public String obterResumo() {
        return String.format(Locale.forLanguageTag("pt-BR"), "%s | %d refeicoes | entrega %s | R$ %,.2f",
                nome, quantidadeRefeicoes, periodicidade.toLowerCase(), valor);
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getQuantidadeRefeicoes() { return quantidadeRefeicoes; }
    public String getPeriodicidade() { return periodicidade; }
    public BigDecimal getValor() { return valor; }
}
