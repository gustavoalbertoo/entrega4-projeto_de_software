package entidade;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Transacao de cobranca da assinatura. Cada tentativa de pagamento gera um objeto Pagamento (DS4). */
public class Pagamento {

    public static final String PENDENTE = "Pendente";
    public static final String APROVADO = "Aprovado";
    public static final String RECUSADO = "Recusado";

    private final BigDecimal valor;
    private final CartaoCredito cartao;
    private LocalDate dataPagamento;      // preenchida so quando aprovado
    private String status = PENDENTE;
    private String codigoAutorizacao = ""; // codigo devolvido pela operadora
    private OperadoraCartaoCredito operadora;

    public Pagamento(BigDecimal valor, CartaoCredito cartao) {
        this.valor = valor;
        this.cartao = cartao;
    }

    public BigDecimal getValor() { return valor; }

    /** Registra a autorizacao da operadora e marca o pagamento como aprovado (DS4, mensagem 12). */
    public void registrarAutorizacao(OperadoraCartaoCredito operadora, String codigoAutorizacao) {
        this.operadora = operadora;
        this.codigoAutorizacao = codigoAutorizacao;
        this.status = APROVADO;
        this.dataPagamento = LocalDate.now();
    }

    /** Marca o pagamento como recusado (fluxo alternativo FA3, DS4 mensagem 16). */
    public void registrarRecusa() {
        this.status = RECUSADO;
    }

    public String getNomeOperadora() { return operadora == null ? "" : operadora.getNome(); }
    public CartaoCredito getCartao() { return cartao; }
    public LocalDate getDataPagamento() { return dataPagamento; }
    public String getStatus() { return status; }
    public String getCodigoAutorizacao() { return codigoAutorizacao; }
}
