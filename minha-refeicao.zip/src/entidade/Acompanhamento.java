package entidade;

import java.util.List;

/** Acompanhamento do cardapio (arroz, feijao, salada etc.). Especializacao de ItemCardapio. */
public class Acompanhamento extends ItemCardapio {

    public Acompanhamento(int id, String nome, String descricao, int calorias, List<String> compativelCom) {
        super(id, nome, descricao, calorias, compativelCom);
    }

    @Override
    public String getCategoria() {
        return ACOMPANHAMENTO;
    }
}
