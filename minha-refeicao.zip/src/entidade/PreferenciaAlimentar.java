package entidade;

/**
 * Restricao alimentar informada pelo assinante: Tradicional, Vegetariana ou Sem lactose.
 * Usada para filtrar os itens do cardapio (DS2, mensagem 8).
 */
public class PreferenciaAlimentar {

    public static final String TRADICIONAL = "Tradicional";
    public static final String VEGETARIANA = "Vegetariana";
    public static final String SEM_LACTOSE = "Sem lactose";

    private final String tipo;

    public PreferenciaAlimentar(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Informa se o item atende a esta preferencia.
     * "Tradicional" nao restringe nada; as demais exigem que o item seja compativel.
     */
    public boolean atende(ItemCardapio item) {
        return TRADICIONAL.equalsIgnoreCase(tipo) || item.isCompativelCom(tipo);
    }

    public String getTipo() { return tipo; }
}
