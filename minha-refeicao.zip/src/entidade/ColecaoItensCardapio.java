package entidade;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Colecao de todos os itens do cardapio. Os dados vem do arquivo dados/cardapio.csv. */
public class ColecaoItensCardapio {

    private final List<ItemCardapio> itens = new ArrayList<>();

    /**
     * Le o CSV e cria o objeto da subclasse correta (PratoPrincipal, Acompanhamento ou Sobremesa)
     * conforme a coluna "categoria". Colunas: id;categoria;nome;descricao;calorias;compativelCom.
     */
    public ColecaoItensCardapio(Path arquivo) {
        if (!Files.exists(arquivo)) {
            throw new IllegalStateException("Arquivo do cardapio nao encontrado: " + arquivo.toAbsolutePath());
        }
        for (String[] c : ArquivoCsv.ler(arquivo)) {
            int id = Integer.parseInt(c[0].trim());
            int calorias = Integer.parseInt(c[4].trim());
            // "Vegetariana|Sem lactose" vira uma lista com dois textos; coluna vazia = lista vazia
            List<String> tipos = c[5].isBlank() ? List.of() : Arrays.asList(c[5].split("\\|"));
            itens.add(switch (c[1].trim()) {
                case ItemCardapio.PRATO_PRINCIPAL -> new PratoPrincipal(id, c[2], c[3], calorias, tipos);
                case ItemCardapio.ACOMPANHAMENTO -> new Acompanhamento(id, c[2], c[3], calorias, tipos);
                case ItemCardapio.SOBREMESA -> new Sobremesa(id, c[2], c[3], calorias, tipos);
                default -> throw new IllegalStateException("Categoria desconhecida no cardapio: " + c[1]);
            });
        }
        if (itens.isEmpty()) {
            throw new IllegalStateException("Nenhum item valido em: " + arquivo.toAbsolutePath());
        }
    }

    /** Itens de uma categoria (DS2, mensagem 6). */
    public List<ItemCardapio> filtrarPorCategoria(String categoria) {
        return itens.stream().filter(i -> i.getCategoria().equals(categoria)).toList();
    }

    /** Busca um item pelo id; devolve null se nao existir (DS2, mensagem 16). */
    public ItemCardapio buscar(int idItem) {
        return itens.stream().filter(i -> i.getId() == idItem).findFirst().orElse(null);
    }
}
