package entidade;

import java.util.Map;

/** Endereco para onde as marmitas serao entregues (DS3, mensagem 6). */
public class EnderecoEntrega {

    private final String cep;
    private final String logradouro;
    private final String numero;
    private final String complemento; // opcional
    private final String bairro;
    private final String cidade;
    private final String estado;

    /** Cria o endereco a partir do mapa {cep, logradouro, numero, complemento, bairro, cidade, estado}. */
    public EnderecoEntrega(Map<String, String> dados) {
        this.cep = dados.get("cep");
        this.logradouro = dados.get("logradouro");
        this.numero = dados.get("numero");
        this.complemento = dados.getOrDefault("complemento", "");
        this.bairro = dados.get("bairro");
        this.cidade = dados.get("cidade");
        this.estado = dados.get("estado");
    }

    /** Endereco em uma unica linha (usado na confirmacao e no arquivo CSV). */
    public String obterEnderecoCompleto() {
        String comp = (complemento == null || complemento.isBlank()) ? "" : " - " + complemento;
        return String.format("%s, %s%s - %s - %s/%s - CEP %s", logradouro, numero, comp, bairro, cidade, estado, cep);
    }

    public String getCep() { return cep; }
    public String getLogradouro() { return logradouro; }
    public String getNumero() { return numero; }
    public String getComplemento() { return complemento; }
    public String getBairro() { return bairro; }
    public String getCidade() { return cidade; }
    public String getEstado() { return estado; }
}
