package entidade;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Cliente que contrata o plano. Tem cadastro completo (nome, genero, e-mail e celular).
 * O celular e validado por SMS; celular e e-mail nao podem se repetir entre assinantes.
 */
public class Assinante {

    private final String nome;
    private final String genero;
    private final String email;
    private final String celular;
    private final List<PreferenciaAlimentar> preferencias = new ArrayList<>();

    public Assinante(String nome, String genero, String email, String celular) {
        this.nome = nome;
        this.genero = genero;
        this.email = email;
        this.celular = celular;
    }

    /** Substitui as preferencias atuais por uma PreferenciaAlimentar para cada tipo informado (DS1, msg 26). */
    public void registrarPreferencias(List<String> tipos) {
        preferencias.clear();
        for (String tipo : tipos) {
            preferencias.add(new PreferenciaAlimentar(tipo));
        }
    }

    public List<PreferenciaAlimentar> obterPreferencias() {
        return List.copyOf(preferencias);
    }

    /** Cria o cartao de credito do assinante a partir dos dados digitados (DS4, mensagens 3 e 4). */
    public CartaoCredito cadastrarCartao(Map<String, String> dadosCartao) {
        return new CartaoCredito(dadosCartao);
    }

    public String getNome() { return nome; }
    public String getGenero() { return genero; }
    public String getEmail() { return email; }
    public String getCelular() { return celular; }
}
