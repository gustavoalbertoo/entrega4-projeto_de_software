package entidade;

/** Liga o pedido a um item do cardapio, guardando a quantidade escolhida (DS2, mensagem 19). */
public class ItemPedido {

    private final ItemCardapio item;
    private final int quantidade;

    public ItemPedido(ItemCardapio item, int quantidade) {
        this.item = item;
        this.quantidade = quantidade;
    }

    /** Descricao de uma linha, ex.: "3x Moqueca de palmito (350 kcal)" (DS2, mensagem 23). */
    public String getDescricao() {
        return quantidade + "x " + item.getNome() + " (" + item.getCalorias() + " kcal)";
    }

    public ItemCardapio getItem() { return item; }
    public int getQuantidade() { return quantidade; }
}
