package entidade;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Conjunto de itens do cardapio escolhidos pelo assinante dentro de uma assinatura. */
public class Pedido {

    public static final String EM_ELABORACAO = "Em Elaboracao";
    public static final String APROVADO = "Aprovado";

    private String status = EM_ELABORACAO;
    private final LocalDate dataPedido = LocalDate.now();
    private final List<ItemPedido> itens = new ArrayList<>();

    /** Soma as quantidades ja escolhidas em uma categoria (usado para validar o limite do plano, FA2). */
    public int totalItens(String categoria) {
        return itens.stream()
                .filter(i -> i.getItem().getCategoria().equals(categoria))
                .mapToInt(ItemPedido::getQuantidade)
                .sum();
    }

    /** Cria um ItemPedido e o adiciona ao pedido. */
    public void adicionarItem(ItemCardapio item, int quantidade) {
        itens.add(new ItemPedido(item, quantidade));
    }

    /** Monta o texto do resumo do pedido, agrupado por categoria (DS2, mensagem 22). */
    public String obterResumo() {
        StringBuilder sb = new StringBuilder();
        for (String categoria : ItemCardapio.CATEGORIAS) {
            // Titulo legivel de cada categoria
            String rotulo = switch (categoria) {
                case ItemCardapio.PRATO_PRINCIPAL -> "Pratos principais";
                case ItemCardapio.ACOMPANHAMENTO -> "Acompanhamentos";
                default -> "Sobremesas";
            };
            sb.append(rotulo).append(":\n");
            boolean algum = false;
            for (ItemPedido ip : itens) {
                if (ip.getItem().getCategoria().equals(categoria)) {
                    sb.append("  - ").append(ip.getDescricao()).append("\n");
                    algum = true;
                }
            }
            if (!algum) {
                sb.append("  (nenhum)\n");
            }
        }
        return sb.toString().stripTrailing();
    }

    /** Muda o status do pedido para Aprovado (chamado quando o pagamento e confirmado). */
    public void aprovar() { this.status = APROVADO; }

    public String getStatus() { return status; }
    public LocalDate getDataPedido() { return dataPedido; }
    public List<ItemPedido> getItens() { return itens; }
}
