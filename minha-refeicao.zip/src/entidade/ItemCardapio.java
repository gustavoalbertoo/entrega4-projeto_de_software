package entidade;

import java.util.List;

/**
 * Item do cardapio (classe abstrata). Suas especializacoes sao PratoPrincipal,
 * Acompanhamento e Sobremesa; cada uma informa a sua categoria em getCategoria().
 */
public abstract class ItemCardapio {

    // Nomes das categorias, usados em todo o sistema
    public static final String PRATO_PRINCIPAL = "PratoPrincipal";
    public static final String ACOMPANHAMENTO = "Acompanhamento";
    public static final String SOBREMESA = "Sobremesa";
    public static final List<String> CATEGORIAS = List.of(PRATO_PRINCIPAL, ACOMPANHAMENTO, SOBREMESA);

    private final int id;
    private final String nome;
    private final String descricao;
    private final int calorias;
    // Preferencias com as quais o item e compativel (ex.: Vegetariana, Sem lactose)
    private final List<String> compativelCom;

    protected ItemCardapio(int id, String nome, String descricao, int calorias, List<String> compativelCom) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.calorias = calorias;
        this.compativelCom = compativelCom;
    }

    /** Cada subclasse devolve a sua categoria (polimorfismo). */
    public abstract String getCategoria();

    /** Verdadeiro se o item e compativel com o tipo de preferencia informado (ignora maiusculas). */
    public boolean isCompativelCom(String tipo) {
        return compativelCom.stream().anyMatch(t -> t.equalsIgnoreCase(tipo));
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public int getCalorias() { return calorias; }
    public List<String> getCompativelCom() { return compativelCom; }
}
