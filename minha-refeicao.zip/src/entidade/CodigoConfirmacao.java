package entidade;

import java.security.SecureRandom;

/**
 * Codigo de confirmacao enviado por SMS ao celular do assinante (DS1, mensagens 3, 4, 9 e 14).
 * Controla tambem o numero de tentativas invalidas (fluxo alternativo FA1: maximo de 3).
 */
public class CodigoConfirmacao {

    public static final int MAX_TENTATIVAS = 3;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final String celular;
    private String codigo;   // codigo gerado (6 digitos)
    private int tentativas;  // quantas vezes o assinante errou o codigo

    public CodigoConfirmacao(String celular) {
        this.celular = celular;
    }

    /** Gera um novo codigo de 6 digitos e zera as tentativas. */
    public String gerar() {
        this.codigo = String.format("%06d", RANDOM.nextInt(1_000_000));
        this.tentativas = 0;
        return codigo;
    }

    /** Compara o codigo informado com o gerado. Se estiver errado, conta uma tentativa. */
    public boolean validar(String informado) {
        boolean ok = codigo != null && informado != null && codigo.equals(informado.trim());
        if (!ok) {
            tentativas++;
        }
        return ok;
    }

    /**
     * Envia o codigo por SMS ao celular do assinante (DS1, mensagem 5).
     * O envio e SIMULADO: a mensagem e apenas exibida no terminal.
     */
    public void enviarSMS() {
        System.out.println();
        System.out.println("  [SMS para " + celular + "] Minha Refeicao: seu codigo de confirmacao e " + codigo);
    }

    /** Verdadeiro quando o assinante ja errou 3 vezes (FA1). */
    public boolean excedeuTentativas() {
        return tentativas >= MAX_TENTATIVAS;
    }

    public String getCelular() { return celular; }
    public String getCodigo() { return codigo; }
    public int getTentativas() { return tentativas; }
}
