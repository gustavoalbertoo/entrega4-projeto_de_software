package entidade;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Map;

/**
 * Operadora de cartao de credito (ator secundario do caso de uso). Esta entidade representa a
 * comunicacao com a operadora: pede a autorizacao do pagamento e devolve a resposta.
 *
 * A operadora e SIMULADA com uma regra simples:
 *   - cartao cujo ULTIMO DIGITO e PAR   -> pagamento aprovado
 *   - cartao cujo ULTIMO DIGITO e IMPAR -> pagamento recusado (fluxo alternativo FA3)
 */
public class OperadoraCartaoCredito {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final String nome;

    public OperadoraCartaoCredito(String nome) {
        this.nome = nome;
    }

    /** DS4: envia o pedido de autorizacao a operadora e recebe o resultado. */
    public RespostaAutorizacao solicitarAutorizacao(Map<String, String> dadosCartao, BigDecimal valor) {
        String numero = dadosCartao.get("numero");

        System.out.println();
        System.out.println(String.format(Locale.forLanguageTag("pt-BR"),
                "  [Operadora] Analisando cobranca de R$ %,.2f ...", valor));

        // Regra da simulacao: olha o ultimo digito do numero do cartao
        int ultimoDigito = Character.digit(numero.charAt(numero.length() - 1), 10);
        boolean aprovado = ultimoDigito % 2 == 0;

        // So existe codigo de autorizacao quando o pagamento e aprovado
        String codigo = aprovado ? "AUT-" + String.format("%06d", RANDOM.nextInt(1_000_000)) : "";
        return new RespostaAutorizacao(aprovado, codigo);
    }

    public String getNome() { return nome; }
}
