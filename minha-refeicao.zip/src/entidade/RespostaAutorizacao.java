package entidade;

/** Resposta da operadora de cartao ao pedido de autorizacao: aprovado ou nao, e o codigo de autorizacao. */
public class RespostaAutorizacao {

    private final boolean aprovado;
    private final String codigoAutorizacao;

    public RespostaAutorizacao(boolean aprovado, String codigoAutorizacao) {
        this.aprovado = aprovado;
        this.codigoAutorizacao = codigoAutorizacao;
    }

    public boolean isAprovado() { return aprovado; }
    public String getCodigoAutorizacao() { return codigoAutorizacao; }
}
