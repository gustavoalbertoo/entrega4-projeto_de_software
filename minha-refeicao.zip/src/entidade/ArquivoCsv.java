package entidade;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Utilitario para ler e gravar arquivos CSV.
 * Formato: separador ponto e virgula (;), codificacao UTF-8, primeira linha = cabecalho.
 */
public final class ArquivoCsv {

    public static final String SEPARADOR = ";";

    // Classe utilitaria: nao deve ser instanciada
    private ArquivoCsv() { }

    /** Le o arquivo e devolve uma lista de linhas ja separadas em colunas (ignora o cabecalho). */
    public static List<String[]> ler(Path arquivo) {
        List<String[]> linhas = new ArrayList<>();
        if (!Files.exists(arquivo)) {
            return linhas; // arquivo ainda nao existe: nenhuma linha
        }
        try {
            List<String> todas = Files.readAllLines(arquivo, StandardCharsets.UTF_8);
            for (int i = 1; i < todas.size(); i++) { // comeca em 1 para pular o cabecalho
                if (!todas.get(i).isBlank()) {
                    // o -1 faz o split manter colunas vazias no final da linha
                    linhas.add(todas.get(i).split(SEPARADOR, -1));
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Erro ao ler " + arquivo, e);
        }
        return linhas;
    }

    /** Verdadeiro se o arquivo existe e a sua primeira linha e igual ao cabecalho esperado. */
    public static boolean cabecalhoIgual(Path arquivo, String cabecalho) {
        try {
            if (!Files.exists(arquivo)) {
                return false;
            }
            List<String> todas = Files.readAllLines(arquivo, StandardCharsets.UTF_8);
            return !todas.isEmpty() && todas.get(0).trim().equals(cabecalho);
        } catch (IOException e) {
            throw new UncheckedIOException("Erro ao ler " + arquivo, e);
        }
    }

    /** Se o arquivo existe com outro formato (versao antiga), ele e renomeado para .antigo. */
    private static void protegerFormatoAntigo(Path arquivo, String cabecalho) throws IOException {
        if (Files.exists(arquivo) && !cabecalhoIgual(arquivo, cabecalho)) {
            Files.move(arquivo, Path.of(arquivo.toString() + ".antigo"),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /** Acrescenta uma linha ao final do arquivo; se o arquivo nao existe, cria com o cabecalho. */
    public static void anexar(Path arquivo, String cabecalho, String linha) {
        try {
            if (arquivo.getParent() != null) {
                Files.createDirectories(arquivo.getParent());
            }
            protegerFormatoAntigo(arquivo, cabecalho);
            if (!Files.exists(arquivo)) {
                Files.writeString(arquivo, cabecalho + System.lineSeparator(), StandardCharsets.UTF_8);
            }
            Files.writeString(arquivo, linha + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new UncheckedIOException("Erro ao gravar " + arquivo, e);
        }
    }

    /** Remove o separador e quebras de linha de um texto para nao quebrar o formato do CSV. */
    public static String limpar(String valor) {
        return valor == null ? "" : valor.replace(SEPARADOR, ",").replace("\r", " ").replace("\n", " ");
    }
}
