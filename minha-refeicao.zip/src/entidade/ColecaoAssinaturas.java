package entidade;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Colecao de assinantes e assinaturas, persistida em arquivos CSV (pasta dados/). Guarda o resultado do caso de uso:
 *  - assinantes.csv   : assinantes com assinatura ATIVA (nome, genero, e-mail, celular, preferencias)
 *  - assinaturas.csv  : a assinatura (status Ativa ou Cancelada), protocolo, endereco, valor
 *  - itens_pedido.csv : os itens escolhidos no pedido
 *  - pagamentos.csv   : todas as tentativas de pagamento (aprovadas e recusadas)
 * Por seguranca, do cartao so os 4 ultimos digitos sao gravados.
 */
public class ColecaoAssinaturas {

    // Cabecalhos (primeira linha) de cada arquivo
    private static final String CAB_ASSINANTES = "celular;nome;genero;email;preferencias";
    private static final String CAB_ASSINATURAS =
            "id;celular;idPlano;plano;status;protocolo;dataContratacao;previsaoPrimeiraEntrega;valorTotal;endereco";
    private static final String CAB_ITENS = "idAssinatura;idItem;categoria;nome;quantidade";
    private static final String CAB_PAGAMENTOS =
            "idAssinatura;dataPagamento;valor;status;codigoAutorizacao;operadora;cartaoFinal";

    private final Path pasta; // pasta onde os arquivos sao gravados

    public ColecaoAssinaturas(Path pasta) {
        this.pasta = pasta;
    }

    /** Verdadeiro se ja existe um assinante cadastrado com este celular (cadastro duplicado). */
    public boolean celularJaCadastrado(String celular) {
        return existeValor(0, celular);
    }

    /** Verdadeiro se ja existe um assinante cadastrado com este e-mail (ignora maiusculas). */
    public boolean emailJaCadastrado(String email) {
        return existeValor(3, email);
    }

    /** Procura um valor em uma coluna de assinantes.csv. Arquivo em formato antigo e ignorado. */
    private boolean existeValor(int coluna, String valor) {
        Path arquivo = pasta.resolve("assinantes.csv");
        if (!ArquivoCsv.cabecalhoIgual(arquivo, CAB_ASSINANTES)) {
            return false; // arquivo ainda nao existe (ninguem cadastrado)
        }
        for (String[] c : ArquivoCsv.ler(arquivo)) {
            if (c.length > coluna && c[coluna].trim().equalsIgnoreCase(valor.trim())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Salva o resultado do caso de uso. A assinatura (Ativa ou Cancelada), os itens e os pagamentos
     * sao sempre gravados. O ASSINANTE so e cadastrado quando a assinatura fica Ativa: assim, quem
     * desiste depois de um pagamento recusado nao fica impedido de tentar de novo (cadastro duplicado).
     */
    public void salvar(Assinatura a) {
        if (a.getStatus().equals(Assinatura.ATIVA)) {
            salvarAssinante(a.getAssinante());
        }

        // Uma linha em assinaturas.csv
        String endereco = a.getEndereco() == null ? "" : a.getEndereco().obterEnderecoCompleto();
        ArquivoCsv.anexar(pasta.resolve("assinaturas.csv"), CAB_ASSINATURAS, String.join(";",
                a.getId(),
                a.getAssinante().getCelular(),
                String.valueOf(a.getPlano().getId()),
                ArquivoCsv.limpar(a.getPlano().getNome()),
                a.getStatus(),
                a.getNumeroProtocolo(),
                a.getDataContratacao().toString(),
                dataOuVazio(a.getPrevisaoPrimeiraEntrega()),
                a.calcularValorTotal().toPlainString(),
                ArquivoCsv.limpar(endereco)));

        // Uma linha para cada item do pedido
        for (ItemPedido ip : a.getPedido().getItens()) {
            ArquivoCsv.anexar(pasta.resolve("itens_pedido.csv"), CAB_ITENS, String.join(";",
                    a.getId(),
                    String.valueOf(ip.getItem().getId()),
                    ip.getItem().getCategoria(),
                    ArquivoCsv.limpar(ip.getItem().getNome()),
                    String.valueOf(ip.getQuantidade())));
        }

        // Uma linha para cada tentativa de pagamento (inclusive as recusadas)
        for (Pagamento p : a.getPagamentos()) {
            ArquivoCsv.anexar(pasta.resolve("pagamentos.csv"), CAB_PAGAMENTOS, String.join(";",
                    a.getId(),
                    dataOuVazio(p.getDataPagamento()),
                    p.getValor().toPlainString(),
                    p.getStatus(),
                    p.getCodigoAutorizacao(),
                    ArquivoCsv.limpar(p.getNomeOperadora()),
                    p.getCartao().getFinal()));
        }
    }

    /** Acrescenta o assinante (com suas preferencias) em assinantes.csv. */
    private void salvarAssinante(Assinante assinante) {
        List<String> preferencias = new ArrayList<>();
        for (PreferenciaAlimentar p : assinante.obterPreferencias()) {
            preferencias.add(p.getTipo());
        }
        ArquivoCsv.anexar(pasta.resolve("assinantes.csv"), CAB_ASSINANTES, String.join(";",
                assinante.getCelular(),
                ArquivoCsv.limpar(assinante.getNome()),
                ArquivoCsv.limpar(assinante.getGenero()),
                ArquivoCsv.limpar(assinante.getEmail()),
                String.join("|", preferencias)));
    }

    private static String dataOuVazio(LocalDate data) {
        return data == null ? "" : data.toString();
    }
}
