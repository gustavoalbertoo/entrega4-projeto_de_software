package entidade;

import java.util.Map;

/** Cartao de credito informado pelo assinante para pagar a assinatura (DS4, mensagem 4). */
public class CartaoCredito {

    private final String numero;
    private final String nomeTitular;
    private final String validade; // formato MM/AA
    private final String bandeira;

    /** Cria o cartao a partir do mapa {numero, nomeTitular, validade, bandeira}. */
    public CartaoCredito(Map<String, String> dados) {
        this.numero = dados.get("numero");
        this.nomeTitular = dados.get("nomeTitular");
        this.validade = dados.get("validade");
        this.bandeira = dados.get("bandeira");
    }

    /** Ultimos 4 digitos (e o unico trecho do numero que o sistema grava). */
    public String getFinal() {
        return numero.substring(Math.max(0, numero.length() - 4));
    }

    public String getNumeroMascarado() { return "**** **** **** " + getFinal(); }
    public String getNumero() { return numero; }
    public String getNomeTitular() { return nomeTitular; }
    public String getValidade() { return validade; }
    public String getBandeira() { return bandeira; }
}
