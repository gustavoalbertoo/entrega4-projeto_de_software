package entidade;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Contrato do assinante com a plataforma. Liga o Assinante, o Plano, o Endereco, o Pedido
 * e os Pagamentos, e concentra o status e o numero de protocolo.
 *
 * Status possiveis: Em Elaboracao -> Aguardando Pagamento -> Ativa (ou Cancelada).
 */
public class Assinatura {

    public static final String EM_ELABORACAO = "Em Elaboracao";
    public static final String AGUARDANDO_PAGAMENTO = "Aguardando Pagamento";
    public static final String ATIVA = "Ativa";
    public static final String CANCELADA = "Cancelada";

    private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // Identificador curto e unico da assinatura (usado nos arquivos CSV)
    private final String id = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    private final Assinante assinante;
    private final PlanoAssinatura plano;
    private final Pedido pedido;
    private final List<Pagamento> pagamentos = new ArrayList<>(); // uma por tentativa de pagamento
    private EnderecoEntrega endereco;
    private String status = EM_ELABORACAO;
    private String numeroProtocolo = "";
    private final LocalDate dataContratacao = LocalDate.now();
    private LocalDate previsaoPrimeiraEntrega;

    /** DS1, mensagens 20 e 21: ao criar a assinatura, ela cria o seu Pedido (vazio). */
    public Assinatura(Assinante assinante, PlanoAssinatura plano) {
        this.assinante = assinante;
        this.plano = plano;
        this.pedido = new Pedido();
    }

    /** Limite de itens por categoria permitido pelo plano (DS2, mensagens 2 e 3). */
    public int obterQuantidadeRefeicoes() {
        return plano.getQuantidadeRefeicoes();
    }

    /**
     * Fluxo alternativo FA2 (DS2, mensagens 12 a 14): verifica se a quantidade solicitada,
     * somada ao que ja foi escolhido na categoria, cabe no limite do plano.
     */
    public boolean validarQuantidade(String categoria, int qtdSolicitada) {
        int limite = plano.getQuantidadeRefeicoes();
        int atual = pedido.totalItens(categoria);
        return qtdSolicitada >= 0 && atual + qtdSolicitada <= limite;
    }

    /**
     * Regra complementar ao FA2: o plano garante N refeicoes, entao o assinante precisa escolher
     * exatamente N pratos principais. Acompanhamentos e sobremesas sao opcionais (ate N cada).
     */
    public boolean validarQuantidadeMinima(String categoria, int qtdSolicitada) {
        if (!categoria.equals(ItemCardapio.PRATO_PRINCIPAL)) {
            return true; // so os pratos principais tem quantidade obrigatoria
        }
        return pedido.totalItens(categoria) + qtdSolicitada >= plano.getQuantidadeRefeicoes();
    }

    /** Repassa o item escolhido para o pedido (DS2, mensagem 17). */
    public void adicionarItem(ItemCardapio item, int quantidade) {
        pedido.adicionarItem(item, quantidade);
    }

    /** Cria o endereco de entrega a partir dos dados digitados (DS3, mensagens 5 e 6). */
    public void definirEndereco(Map<String, String> dadosEndereco) {
        this.endereco = new EnderecoEntrega(dadosEndereco);
    }

    /** Passa o status para Aguardando Pagamento (fluxo principal, passo 23). */
    public void aguardarPagamento() {
        this.status = AGUARDANDO_PAGAMENTO;
    }

    /** Valor total da assinatura = valor do plano (DS3, mensagens 8 e 9). */
    public BigDecimal calcularValorTotal() {
        return plano.getValor();
    }

    /** Cria um Pagamento para o cartao informado e o guarda na assinatura (DS4, mensagens 5 a 7). */
    public Pagamento gerarPagamento(CartaoCredito cartao) {
        BigDecimal valor = calcularValorTotal();
        Pagamento pagamento = new Pagamento(valor, cartao);
        pagamentos.add(pagamento);
        return pagamento;
    }

    /** Pagamento aprovado: assinatura fica Ativa e o pedido Aprovado (DS4, mensagens 14 e 15). */
    public void ativar() {
        this.status = ATIVA;
        pedido.aprovar();
    }

    /** O assinante desistiu depois de um pagamento recusado (FA3): a assinatura e cancelada. */
    public void encerrarSemAtivacao() {
        this.status = CANCELADA;
    }

    /** Gera o numero de protocolo, ex.: MR-20261114-8DBAB9 (DS5, mensagem 1). */
    public String gerarProtocolo() {
        this.numeroProtocolo = "MR-" + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
                + "-" + id.substring(0, 6);
        return numeroProtocolo;
    }

    /**
     * Previsao da primeira entrega (DS5, mensagens 3 e 4): data da contratacao mais um prazo
     * de preparo que depende da periodicidade do plano (Semanal 2 dias, Quinzenal 3, Mensal 5).
     */
    public LocalDate calcularPrevisaoPrimeiraEntrega() {
        int dias = switch (plano.getPeriodicidade().toLowerCase()) {
            case "semanal" -> 2;
            case "quinzenal" -> 3;
            default -> 5;
        };
        this.previsaoPrimeiraEntrega = dataContratacao.plusDays(dias);
        return previsaoPrimeiraEntrega;
    }

    /** Texto da mensagem de confirmacao final (DS5, mensagens 5 a 8). */
    public String obterDadosConfirmacao() {
        StringBuilder sb = new StringBuilder();
        sb.append("Assinante        : ").append(assinante.getNome()).append(" (").append(assinante.getEmail()).append(")\n");
        sb.append("Plano contratado : ").append(plano.getNome()).append("\n");
        sb.append("Periodicidade    : ").append(plano.getPeriodicidade()).append("\n");
        sb.append("Refeicoes selecionadas:\n");
        for (String linha : pedido.obterResumo().split("\n")) {
            sb.append("  ").append(linha).append("\n");
        }
        sb.append("Endereco         : ").append(endereco.obterEnderecoCompleto()).append("\n");
        sb.append("Prev. 1a entrega : ").append(previsaoPrimeiraEntrega.format(DATA)).append("\n");
        sb.append("No do protocolo  : ").append(numeroProtocolo);
        return sb.toString();
    }

    public String getId() { return id; }
    public Assinante getAssinante() { return assinante; }
    public PlanoAssinatura getPlano() { return plano; }
    public Pedido getPedido() { return pedido; }
    public List<Pagamento> getPagamentos() { return List.copyOf(pagamentos); }
    public EnderecoEntrega getEndereco() { return endereco; }
    public String getStatus() { return status; }
    public String getNumeroProtocolo() { return numeroProtocolo; }
    public LocalDate getDataContratacao() { return dataContratacao; }
    public LocalDate getPrevisaoPrimeiraEntrega() { return previsaoPrimeiraEntrega; }
}
