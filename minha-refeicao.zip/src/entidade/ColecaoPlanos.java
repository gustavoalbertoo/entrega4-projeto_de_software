package entidade;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Colecao dos planos de assinatura disponiveis. Os dados vem do arquivo dados/planos.csv. */
public class ColecaoPlanos {

    private final List<PlanoAssinatura> planos = new ArrayList<>();

    /** Le o CSV e cria um PlanoAssinatura para cada linha. Colunas: id;nome;quantidade;periodicidade;valor. */
    public ColecaoPlanos(Path arquivo) {
        if (!Files.exists(arquivo)) {
            throw new IllegalStateException("Arquivo de planos nao encontrado: " + arquivo.toAbsolutePath());
        }
        for (String[] c : ArquivoCsv.ler(arquivo)) {
            planos.add(new PlanoAssinatura(Integer.parseInt(c[0].trim()), c[1].trim(), Integer.parseInt(c[2].trim()),
                    c[3].trim(), new BigDecimal(c[4].trim())));
        }
        if (planos.isEmpty()) {
            throw new IllegalStateException("Nenhum plano valido em: " + arquivo.toAbsolutePath());
        }
    }

    /** Todos os planos (DS1, mensagem 11). */
    public List<PlanoAssinatura> listar() {
        return List.copyOf(planos);
    }

    /** Busca um plano pelo id; devolve null se nao existir (DS1, mensagem 19). */
    public PlanoAssinatura buscar(int idPlano) {
        return planos.stream().filter(p -> p.getId() == idPlano).findFirst().orElse(null);
    }
}
