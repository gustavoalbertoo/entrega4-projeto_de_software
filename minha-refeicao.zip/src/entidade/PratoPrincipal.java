package entidade;

import java.util.List;

/** Prato principal do cardapio (carne, peixe, vegetariano etc.). Especializacao de ItemCardapio. */
public class PratoPrincipal extends ItemCardapio {

    public PratoPrincipal(int id, String nome, String descricao, int calorias, List<String> compativelCom) {
        super(id, nome, descricao, calorias, compativelCom);
    }

    @Override
    public String getCategoria() {
        return PRATO_PRINCIPAL;
    }
}
