package entidade;

import java.util.List;

/** Sobremesa do cardapio. Especializacao de ItemCardapio. */
public class Sobremesa extends ItemCardapio {

    public Sobremesa(int id, String nome, String descricao, int calorias, List<String> compativelCom) {
        super(id, nome, descricao, calorias, compativelCom);
    }

    @Override
    public String getCategoria() {
        return SOBREMESA;
    }
}
