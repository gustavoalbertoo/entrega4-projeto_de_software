package entidade;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

/** Cardapio da semana atual. Delega a busca dos itens para a ColecaoItensCardapio. */
public class Cardapio {

    private final LocalDate dataInicio; // segunda-feira da semana atual
    private final LocalDate dataFim;    // domingo da semana atual
    private final ColecaoItensCardapio colecaoItens;

    public Cardapio(ColecaoItensCardapio colecaoItens) {
        LocalDate hoje = LocalDate.now();
        this.dataInicio = hoje.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        this.dataFim = dataInicio.plusDays(6);
        this.colecaoItens = colecaoItens;
    }

    /**
     * Itens de uma categoria que atendem a TODAS as preferencias do assinante (DS2, mensagens 5 a 8).
     * Ex.: com Vegetariana e Sem lactose, so aparecem itens compativeis com as duas.
     */
    public List<ItemCardapio> listarItens(String categoria, List<PreferenciaAlimentar> prefs) {
        List<ItemCardapio> resultado = new ArrayList<>();
        for (ItemCardapio item : colecaoItens.filtrarPorCategoria(categoria)) {
            boolean atende = true;
            for (PreferenciaAlimentar pref : prefs) {
                if (!pref.atende(item)) {
                    atende = false; // basta uma preferencia nao atendida para descartar o item
                    break;
                }
            }
            if (atende) {
                resultado.add(item);
            }
        }
        return resultado;
    }

    /** Busca um item pelo id (DS2, mensagem 15). */
    public ItemCardapio buscarItem(int idItem) {
        return colecaoItens.buscar(idItem);
    }

    public LocalDate getDataInicio() { return dataInicio; }
    public LocalDate getDataFim() { return dataFim; }
}
